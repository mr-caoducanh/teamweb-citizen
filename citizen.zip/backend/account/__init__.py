class CadreLevels:
    CENTRAL = "0"
    CITY = "1"
    DISTRICT = "2"
    COMMUNE = "3"
    VILLAGE = "4"

    CHOICES = [
        (CENTRAL, 'Central'),#A1
        (CITY, 'City'), #A2
        (DISTRICT, 'District'),#A3 
        (COMMUNE, 'Commune'), #B1
        (VILLAGE, 'Village'), #B2   
    ]
    